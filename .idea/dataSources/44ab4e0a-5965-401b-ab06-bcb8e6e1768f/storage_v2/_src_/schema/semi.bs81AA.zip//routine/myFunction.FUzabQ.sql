create
    definer = SAMPLE@`%` procedure myFunction()
BEGIN
    DECLARE i INT DEFAULT 1;
    WHILE (i <= 300 ) DO
        INSERT INTO tbl_procode(codeNo, codeMainC, codeMiddleC) values ((select proidx from tbl_productcrawlcopy where proidx=i),(select codeMain from tbl_productcrawlcopy where proidx=i),(select codeMiddle from tbl_productcrawlcopy where proidx=i));
        SET i = i + 1;
    END WHILE;
end;

